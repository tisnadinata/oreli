<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

$_['select_payment'] = 'Please select the payment channel to use'; 
 
?>

