<html>
	<head>
		<title>Payment Cancel!</title>
	</head>

<body>


	<h2>Payment was cancelled!</h2>
	<h3>Your Payment was not successful, go back to our shop and try again.</h3>
	<h3><a href="http://www.onlinetuting.com/myshop">Go to back</a></h3>



</body>
</html>